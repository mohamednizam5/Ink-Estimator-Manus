#!/usr/bin/env python3
"""
CMYK Ink Coverage Analyzer
Accepts a single image path and outputs JSON with per-channel coverage metrics.
Usage: python3 analyze_cmyk.py <image_path>
"""
import sys
import json
import os

try:
    from PIL import Image
    import numpy as np
except ImportError as e:
    print(json.dumps({"error": f"Missing dependency: {e}"}))
    sys.exit(1)


def rgb_to_cmyk(r, g, b):
    """Convert RGB (0-255) arrays to CMYK (0-1) arrays."""
    r_norm = r / 255.0
    g_norm = g / 255.0
    b_norm = b / 255.0

    k = 1.0 - np.maximum(np.maximum(r_norm, g_norm), b_norm)
    # Avoid division by zero for pure black pixels
    divisor = np.where(k < 1.0, 1.0 - k, 1.0)

    c = np.where(k < 1.0, (1.0 - r_norm - k) / divisor, 0.0)
    m = np.where(k < 1.0, (1.0 - g_norm - k) / divisor, 0.0)
    y = np.where(k < 1.0, (1.0 - b_norm - k) / divisor, 0.0)

    return (
        np.clip(c, 0, 1),
        np.clip(m, 0, 1),
        np.clip(y, 0, 1),
        np.clip(k, 0, 1),
    )


def analyze_image(image_path):
    img = Image.open(image_path)

    # Handle RGBA — extract alpha mask for background exclusion
    if img.mode == "RGBA":
        r, g, b, a = img.split()
        alpha_mask = np.array(a) > 10  # pixels with alpha > 10 are "ink"
        img = img.convert("RGB")
    elif img.mode in ("LA", "L"):
        img = img.convert("RGB")
        alpha_mask = None
    else:
        img = img.convert("RGB")
        alpha_mask = None

    img_array = np.array(img, dtype=np.float32)
    r = img_array[:, :, 0]
    g = img_array[:, :, 1]
    b = img_array[:, :, 2]

    # Identify white/near-white background pixels (R>245, G>245, B>245)
    is_white = (r > 245) & (g > 245) & (b > 245)

    # Build ink mask: not white AND not transparent
    if alpha_mask is not None:
        ink_mask = (~is_white) & alpha_mask
    else:
        ink_mask = ~is_white

    total_pixels = r.size
    ink_pixels = int(np.sum(ink_mask))

    if ink_pixels == 0:
        return {
            "cCoverage": 0.0,
            "mCoverage": 0.0,
            "yCoverage": 0.0,
            "kCoverage": 0.0,
            "tac": 0.0,
            "totalPixels": total_pixels,
            "inkPixels": 0,
        }

    c, m, y, k = rgb_to_cmyk(r, g, b)

    # Compute average coverage over ALL pixels (industry standard: coverage = avg ink across page)
    c_cov = float(np.mean(c) * 100)
    m_cov = float(np.mean(m) * 100)
    y_cov = float(np.mean(y) * 100)
    k_cov = float(np.mean(k) * 100)
    tac = c_cov + m_cov + y_cov + k_cov

    return {
        "cCoverage": round(c_cov, 4),
        "mCoverage": round(m_cov, 4),
        "yCoverage": round(y_cov, 4),
        "kCoverage": round(k_cov, 4),
        "tac": round(tac, 4),
        "totalPixels": total_pixels,
        "inkPixels": ink_pixels,
    }


def rasterize_pdf(pdf_path, output_dir, dpi=150):
    """Rasterize each page of a PDF to PNG images. Returns list of image paths."""
    try:
        from pdf2image import convert_from_path
        pages = convert_from_path(pdf_path, dpi=dpi, output_folder=output_dir, fmt="png", output_file="page")
        paths = []
        for i, page in enumerate(pages):
            out_path = os.path.join(output_dir, f"page_{i+1:04d}.png")
            page.save(out_path, "PNG")
            paths.append(out_path)
        return paths
    except Exception as e:
        return {"error": str(e)}


def rasterize_docx(docx_path, output_dir, dpi=150):
    """Convert DOCX to PDF via LibreOffice, then rasterize."""
    import subprocess
    try:
        result = subprocess.run(
            ["libreoffice", "--headless", "--convert-to", "pdf", "--outdir", output_dir, docx_path],
            capture_output=True, text=True, timeout=120
        )
        if result.returncode != 0:
            return {"error": f"LibreOffice failed: {result.stderr}"}
        # Find the generated PDF
        base = os.path.splitext(os.path.basename(docx_path))[0]
        pdf_path = os.path.join(output_dir, base + ".pdf")
        if not os.path.exists(pdf_path):
            return {"error": "LibreOffice did not produce a PDF"}
        return rasterize_pdf(pdf_path, output_dir, dpi)
    except Exception as e:
        return {"error": str(e)}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"error": "Usage: analyze_cmyk.py <image_path>"}))
        sys.exit(1)

    image_path = sys.argv[1]
    if not os.path.exists(image_path):
        print(json.dumps({"error": f"File not found: {image_path}"}))
        sys.exit(1)

    try:
        result = analyze_image(image_path)
        print(json.dumps(result))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
        sys.exit(1)
