# Ink Coverage & Print Cost Calculator — TODO

## Database & Schema
- [x] Create `analysis_sessions` table (id, userId, mode, status, shareToken, expiresAt, createdAt)
- [x] Create `uploaded_files` table (id, sessionId, filename, mimeType, storageKey, pageCount, createdAt)
- [x] Create `page_analyses` table (id, fileId, pageNumber, cCoverage, mCoverage, yCoverage, kCoverage, tac, thumbnailKey)
- [x] Create `cost_presets` table (id, userId, name, pricePerCartridge, yieldPages, coveragePercent, pricePerMl, mlPerCartridge, paperCostPerSheet, isDefault)
- [x] Create `paper_presets` table (id, name, width, height, unit, isBuiltIn)
- [x] Create `ai_summaries` table (id, sessionId, summary, recommendations)
- [x] Run migration SQL
- [x] Seed built-in paper presets (A4, A3, A5, Letter, Legal, Tabloid)
- [x] Seed built-in cost presets (HP LaserJet, Canon Inkjet, Epson EcoTank, Brother Laser)

## Backend / Server
- [x] Install sharp, multer, pdf-lib, papaparse, uuid npm packages
- [x] Install python-shell for Python subprocess integration
- [x] Python CMYK analysis script (analyze_cmyk.py) with RGB→CMYK conversion, background exclusion
- [x] Python rasterization script (rasterize.py) for PDF/DOCX/EPS/image files
- [x] File upload endpoint with multer (50MB limit, supported types validation)
- [x] Server-side rasterization: PDF via pdf2image/pdftoppm, DOCX via LibreOffice headless
- [x] CMYK pixel analysis using Python/Pillow: per-channel coverage, TAC, background exclusion
- [x] Per-page thumbnail generation and storage upload
- [x] tRPC router: `analysis.createSession` — create session with mode and share token
- [x] tRPC router: `analysis.getSession` — poll session status
- [x] tRPC router: `analysis.getResults` — get full results with files, pages, AI summary
- [x] tRPC router: `analysis.getByShareToken` — public shared result access
- [x] tRPC router: `analysis.computeCosts` — cost calculation with per-page/channel breakdown
- [x] tRPC router: `analysis.generateAISummary` — LLM plain-language summary + recommendations
- [x] tRPC router: `analysis.exportCSV` — generate and return CSV
- [x] tRPC router: `analysis.exportPDF` — generate PDF report and return download URL
- [x] tRPC router: `presets.listCost`, `presets.saveCost`, `presets.deleteCost` — cost preset CRUD
- [x] tRPC router: `presets.listPaper` — list paper size presets
- [x] Share token generation (UUID-based, 32-char hex)
- [x] TTL-based expiry: sessions expire after 24h
- [x] Private/in-memory mode: skip storage, process in-memory only
- [x] Analysis service orchestrating rasterization, analysis, storage, and AI summary
- [x] Export service for CSV and PDF report generation

## Frontend
- [x] Global CSS: elegant palette (Inter + Playfair Display), CMYK channel colors, animations
- [x] Step indicator component (Upload → Analyze → Configure → Results → Export)
- [x] CMYK coverage bar component with animated fills
- [x] Step 1 — Upload: drag-and-drop zone, file list, private mode toggle, 50MB validation
- [x] Step 2 — Analyze: animated progress indicator, per-file status
- [x] Step 3 — Configure Costs: cost input form, preset selector/saver, paper size selector
- [x] Step 4 — Results: per-page table, CMYK bar charts (recharts), cost breakdown, AI summary inline
- [x] Step 5 — Export/Share: CSV download, PDF report download, shareable link copy
- [x] Shared result page (/share/:token) for public viewing
- [x] Responsive layout, mobile-first
- [x] Smooth step transitions with framer-motion
- [x] Private mode disables sharing

## Tests
- [x] Unit test: cost calculation formula (cartridge, per-mL, duplex, copies, zero coverage)
- [x] Unit test: share token generation (uniqueness, format)
- [x] Unit test: auth logout (existing template test)

## PDF Export Enhancement
- [x] Upgrade generatePdfReport: multi-column summary table, CMYK color-coded bars, cost summary box, styled header/footer with page numbers
- [x] Add direct PDF download (blob trigger) for both standard and private sessions in the frontend
- [x] Add PDF export button in the Results step (step 4) as a quick-action shortcut
- [x] Add PDF export to the SharedResult page so viewers can download a report
- [x] Write vitest unit tests for generatePdfReport (output is a Buffer, has correct byte header)
- [x] Persist chosen cost params on the session so shared PDF exports include the cost breakdown
- [x] Add exportPdfByShareToken router procedure that validates expiry and builds report from persisted data

## Logo Branding in PDF
- [x] Download SCTDJM logo from sctdjm.com
- [x] Upload logo to webdev static assets storage
- [x] Embed logo image in PDF report header alongside company name
- [x] Test PDF generation produces a valid branded report
- [x] Embed logo as a base64 constant in exportService.ts so it is always available in production without a file path dependency

## Email Report Feature
- [ ] Install nodemailer and set up SMTP email service
- [ ] Add SMTP credentials via webdev_request_secrets
- [ ] Build sendReportEmail tRPC procedure: generate PDF, attach, send
- [ ] Add "Share via Email" button next to the PDF download banner on Step 4 Results
- [ ] Add email input dialog with recipient address, subject, and optional message
- [ ] Add email input + send button UI on the Export step (step 5)
- [ ] Add loading, success, and error states to the email UI
- [ ] Write vitest unit tests for email validation and procedure logic

## Per-Color Cartridge Pricing
- [x] Extend CostParams with cPrice, mPrice, yPrice, kPrice (price per cartridge per channel)
- [x] Update computeCosts to use per-channel prices in cost calculation
- [x] Update Configure step UI with color-coded C/M/Y/K price inputs
- [x] Update PDF report to show per-channel cost breakdown
- [x] Update CSV export to include per-channel cost columns
- [x] Update vitest tests for per-color cost calculation

## Cartridge Brand Presets (HP, Canon, Epson)
- [x] Research and compile HP, Canon, Epson CMYK cartridge prices and yields
- [x] Extend cost_presets schema/data to support per-channel CMYK pricing fields
- [x] Seed database with HP, Canon, Epson cartridge presets
- [x] Update Configure step UI with brand-grouped preset selector that auto-fills CMYK fields
- [x] Write vitest tests for preset seeding and auto-fill logic

## Brother Cartridge Presets (TN-227, TN-433 series)
- [x] Research Brother TN-227 and TN-433 series CMYK toner prices and yields
- [x] Seed database with Brother cartridge presets
- [x] Add Brother brand tab to the Configure step preset UI
- [x] Write vitest tests for Brother preset data

## Samsung & Xerox Cartridge Presets
- [x] Research Samsung and Xerox CMYK toner prices and yields
- [x] Seed database with Samsung and Xerox cartridge presets
- [x] Add Samsung and Xerox brand tabs to the Configure step preset UI
- [x] Write vitest tests for Samsung and Xerox preset data

## Lexmark & Konica Minolta Cartridge Presets
- [x] Research Lexmark and Konica Minolta CMYK toner prices and yields
- [x] Seed database with Lexmark and Konica Minolta cartridge presets
- [x] Add Lexmark and Konica Minolta brand tabs to the Configure step preset UI
- [x] Write vitest tests for Lexmark and Konica Minolta preset data

## Printer Selection Flow
- [x] Design printers table schema linked to cost_presets (brand, model, series, presetId)
- [x] Seed printer models for all 8 brands (HP, Canon, Epson, Brother, Samsung, Xerox, Lexmark, Konica Minolta)
- [x] Add tRPC procedures: listBrands, listPrintersByBrand, getPresetByPrinter
- [x] Update Configure step UI: Brand → Printer Model → Toner auto-fill flow
- [x] Write vitest tests for printer lookup and toner auto-fill logic
- [x] Confirm printer router procedure names match frontend usage

## Bug Fixes
- [x] Fix TRPCClientError "Unexpected token '<'" — added JSON catch-all for /api/* routes before Vite fallback to prevent HTML being returned for unmatched API paths (implemented as printers.listBrands, printers.listByBrand, printers.getPreset — all frontend callers verified)

## PDF Download UX Enhancement
- [x] Add prominent PDF download banner at the top of Step 4 (Results) with a red solid button and descriptive text
- [x] Existing PDF download buttons on Step 4 bottom bar, Step 5 Export card, and SharedResult page confirmed working
